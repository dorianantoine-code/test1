'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [username, setU] = useState('');
  const [password, setP] = useState('');
  const [gtk, setGtk] = useState('');
  const [cookieHeader, setCookieHeader] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [loading, setL] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const loadGtk = async () => {
      setErr(null);
      try {
        const r = await fetch('/api/ed/gtk');
        const j = await r.json();
        if (!r.ok) {
          setErr(j.error || 'Impossible d’obtenir GTK');
          return;
        }
        setGtk(j.gtk);
        setCookieHeader(j.cookieHeader || '');
        console.log('[UI] GTK ok, cookieKeys=', j.cookieKeys);
      } catch (e: any) {
        setErr(e?.message || 'Erreur GTK');
      }
    };
    loadGtk();
  }, []);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setL(true);
    try {
      const res = await fetch('/api/ed/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, gtk, cookieHeader }),
      });
      const json = await res.json();
      console.log('[UI] /api/ed/login ->', json);
      if (json.needsQCM && json.token && json.gtk) {
        router.push(
          `/ed/qcm?gtk=${encodeURIComponent(json.gtk)}&token=${encodeURIComponent(
            json.token,
          )}&ch=${encodeURIComponent(json.cookieHeader || '')}&u=${encodeURIComponent(username)}`,
        );
        return;
      }

      if (!res.ok) {
        setErr(json.error || 'Échec de connexion');
        return;
      }

      router.push('/dashboard'); // (tu pourras créer cette page après)
    } catch (e: any) {
      setErr(e?.message || 'Erreur réseau');
    } finally {
      setL(false);
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-100 p-6">
      <form
        onSubmit={onSubmit}
        className="bg-white w-full max-w-sm p-6 rounded-xl shadow space-y-4"
      >
        <h1 className="text-xl font-bold">Connexion École Directe</h1>
        <input
          className="w-full border rounded px-3 py-2"
          placeholder="Identifiant (ED, pas e-mail)"
          value={username}
          onChange={(e) => setU(e.target.value)}
        />
        <input
          type="password"
          className="w-full border rounded px-3 py-2"
          placeholder="Mot de passe"
          value={password}
          onChange={(e) => setP(e.target.value)}
        />
        {err && <p className="text-sm text-red-600">{err}</p>}
        <button
          disabled={loading || !gtk}
          className="w-full bg-blue-600 text-white rounded px-3 py-2 hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Connexion…' : gtk ? 'Valider' : 'Init GTK…'}
        </button>
        <p className="text-xs text-gray-500">
          Astuce: utilise l’<b>identifiant</b> École Directe (pas l’e-mail).
        </p>
      </form>
    </main>
  );
}
