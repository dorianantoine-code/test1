import { NextResponse } from 'next/server';
import { prelogin } from '../_shared';

export const runtime = 'nodejs';

export async function GET() {
  const { gtk, cookieHeader, jar } = await prelogin();
  if (!gtk) {
    return NextResponse.json(
      { error: 'GTK introuvable', cookieKeys: Object.keys(jar || {}) },
      { status: 502 },
    );
  }
  return NextResponse.json({ gtk, cookieHeader, cookieKeys: Object.keys(jar || {}) });
}
