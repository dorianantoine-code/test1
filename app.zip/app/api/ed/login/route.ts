import { NextRequest, NextResponse } from 'next/server';
import axios from 'axios';

// --- Config par défaut (peut être surchargée depuis le body)
const ED_BASE = 'https://api.ecoledirecte.com';
const DEFAULT_ED_VERSION = '4.75.0'; // ← ton header fonctionnel

// Client axios « brut » (sans encodage automatique spécial)
const axiosBase = axios.create({
  timeout: 15000,
  // Active si besoin (VPN/MI): ED_INSECURE_TLS=1 next dev
  httpsAgent: process.env.ED_INSECURE_TLS
    ? new (require('https').Agent)({ rejectUnauthorized: false })
    : undefined,
});

const DEBUG = true;

// --- Utils
function mask(v?: string | null, left = 2, right = 2) {
  if (!v) return '';
  if (v.length <= left + right) return '*'.repeat(v.length);
  return v.slice(0, left) + '…' + v.slice(-right);
}

function decodeIfEncoded(s?: string) {
  if (!s) return '';
  return /%[0-9A-Fa-f]{2}/.test(s) ? decodeURIComponent(s) : s;
}

function ensureGtk(cookieHeader: string, gtk: string) {
  const ch = (cookieHeader || '').trim();
  if (!ch) return `GTK=${gtk}`;
  if (/(^|;\s*)GTK=[^;]+/.test(ch)) return ch; // déjà présent
  return `${ch}; GTK=${gtk}`;
}

// fusionne les Set-Cookie reçus en un header Cookie pour les appels suivants
function mergeSetCookies(...sets: (string[] | undefined)[]) {
  const jar: Record<string, string> = {};
  for (const sc of sets) {
    if (!sc) continue;
    for (const line of sc) {
      const [kv] = line.split(';');
      const i = kv.indexOf('=');
      if (i > 0) {
        const k = kv.slice(0, i).trim();
        const v = kv.slice(i + 1).trim();
        if (k) jar[k] = v;
      }
    }
  }
  return Object.entries(jar)
    .map(([k, v]) => `${k}=${v}`)
    .join('; ');
}

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const username: string | undefined = body?.username; // l’email peut être accepté selon le tenant
    const password: string | undefined = body?.password;
    const gtk: string | undefined = body?.gtk;
    const cookieHeaderIn: string | undefined = body?.cookieHeader;
    const edVersion: string = body?.version || DEFAULT_ED_VERSION;

    if (!username || !password || !gtk) {
      return NextResponse.json({ error: 'username, password, gtk requis' }, { status: 400 });
    }

    // 1) Cookie d’entrée: décoder si %xx, et garantir GTK=
    const chDecoded = decodeIfEncoded(cookieHeaderIn);
    const cookieForLogin = ensureGtk(chDecoded, gtk);

    // 2) En-têtes au plus proche de ton header « qui marche »
    const baseHeaders = {
      'User-Agent':
        'Mozilla/5.0 (Linux; Android 13; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36',
      Accept: '*/*',
      'Accept-Language': 'fr-FR,fr;q=0.5',
      Pragma: 'no-cache',
      'Cache-Control': 'no-cache',
      'X-Requested-With': 'XMLHttpRequest',
      'X-Client': 'EDWEB',
      'X-Gtk': gtk,
      Origin: 'https://www.ecoledirecte.com',
      Referer: 'https://www.ecoledirecte.com/',
      Cookie: cookieForLogin, // IMPORTANT: doit contenir GTK + le « gros » cookie opaque
    } as const;

    const url = `${ED_BASE}/v3/login.awp?v=${edVersion}`;
    const payload = {
      identifiant: username,
      motdepasse: password,
      isReLogin: false, // orthographe aussi vue: isRelogin (on garde isReLogin ici)
      uuid: '',
    };

    // ---- STEP 1: text/plain;charset=UTF-8 (exact du header fourni)
    const bodyTxt = `data=${encodeURIComponent(JSON.stringify(payload))}`;
    if (DEBUG) {
      console.log('[ED/login][STEP1 text/plain][REQUEST]', {
        url,
        cookieLen: baseHeaders.Cookie.length,
        gtkMasked: mask(gtk),
        usernameMasked: mask(username),
        bodyPreview: bodyTxt.slice(0, 120) + '…',
      });
    }
    let res = await axiosBase.post(url, bodyTxt, {
      headers: { ...baseHeaders, 'Content-Type': 'text/plain;charset=UTF-8' },
      // Important: pas de transformRequest custom; on envoie la string brute
      maxRedirects: 0,
      validateStatus: () => true, // on lit toujours la réponse
    });
    let json: any = res.data;
    let xToken = (res.headers['x-token'] as string) || json?.token || '';

    if (DEBUG) {
      console.log('[ED/login][STEP1 text/plain][RESPONSE]', {
        httpStatus: res.status,
        code: json?.code,
        message: json?.message,
        xTokenPresent: !!xToken,
        setCookieCount: Array.isArray(res.headers['set-cookie'])
          ? res.headers['set-cookie'].length
          : 0,
      });
    }

    // Succès sans 2FA (code 200) → renvoie identité + cookies fusionnés
    if (json?.code === 200 && json?.data?.accounts?.length) {
      const set1 = Array.isArray(res.headers['set-cookie'])
        ? (res.headers['set-cookie'] as string[])
        : undefined;
      const cookieOut = mergeSetCookies(set1);
      const acc = json.data.accounts[0];

      return NextResponse.json({
        ok: true,
        gtk,
        token: xToken || '',
        cookieHeader: cookieOut,
        identity: {
          id: acc?.id,
          type: acc?.type,
          nom: acc?.nom ?? acc?.lastName,
          prenom: acc?.prenom ?? acc?.firstName,
        },
      });
    }

    // 2FA requis (code 250) → renvoie token + cookies
    if (json?.code === 250 && xToken && xToken.length > 0) {
      const set1 = Array.isArray(res.headers['set-cookie'])
        ? (res.headers['set-cookie'] as string[])
        : undefined;
      const cookieOut = mergeSetCookies(set1);

      if (DEBUG) {
        console.log('[ED/login] 2FA requis → token présent, on passe au QCM');
      }
      return NextResponse.json({
        needsQCM: true,
        gtk,
        token: xToken,
        cookieHeader: cookieOut,
        message: json?.message ?? null,
        version: edVersion,
      });
    }

    // ---- STEP 2: fallback en application/x-www-form-urlencoded
    const formBody = new URLSearchParams({ data: JSON.stringify(payload) }).toString();
    if (DEBUG) {
      console.log('[ED/login][STEP2 x-www-form][REQUEST]', {
        url,
        cookieLen: baseHeaders.Cookie.length,
        gtkMasked: mask(gtk),
        bodyPreview: formBody.slice(0, 120) + '…',
      });
    }
    res = await axiosBase.post(url, formBody, {
      headers: { ...baseHeaders, 'Content-Type': 'application/x-www-form-urlencoded' },
      maxRedirects: 0,
      validateStatus: () => true,
    });
    json = res.data;
    xToken = (res.headers['x-token'] as string) || json?.token || '';

    if (DEBUG) {
      console.log('[ED/login][STEP2 x-www-form][RESPONSE]', {
        httpStatus: res.status,
        code: json?.code,
        message: json?.message,
        xTokenPresent: !!xToken,
        setCookieCount: Array.isArray(res.headers['set-cookie'])
          ? res.headers['set-cookie'].length
          : 0,
      });
    }

    if (json?.code === 200 && json?.data?.accounts?.length) {
      const set2 = Array.isArray(res.headers['set-cookie'])
        ? (res.headers['set-cookie'] as string[])
        : undefined;
      const cookieOut = mergeSetCookies(set2);
      const acc = json.data.accounts[0];

      return NextResponse.json({
        ok: true,
        gtk,
        token: xToken || '',
        cookieHeader: cookieOut,
        identity: {
          id: acc?.id,
          type: acc?.type,
          nom: acc?.nom ?? acc?.lastName,
          prenom: acc?.prenom ?? acc?.firstName,
        },
      });
    }

    if (json?.code === 250 && xToken && xToken.length > 0) {
      const set2 = Array.isArray(res.headers['set-cookie'])
        ? (res.headers['set-cookie'] as string[])
        : undefined;
      const cookieOut = mergeSetCookies(set2);

      if (DEBUG) console.log('[ED/login] 2FA requis → token présent, on passe au QCM');
      return NextResponse.json({
        needsQCM: true,
        gtk,
        token: xToken,
        cookieHeader: cookieOut,
        message: json?.message ?? null,
        version: edVersion,
      });
    }

    // Échec
    if (DEBUG)
      console.log('[ED/login] FAIL', {
        code: json?.code,
        message: json?.message,
        xTokenPresent: !!xToken,
      });
    return NextResponse.json(
      {
        error: json?.message || 'Identifiant et/ou mot de passe invalide !',
        raw: json,
        xTokenPresent: !!xToken,
      },
      { status: 401 },
    );
  } catch (e: any) {
    if (DEBUG) console.error('[ED/login] ERROR', e?.message || e);
    return NextResponse.json({ error: e?.message || 'Erreur serveur' }, { status: 500 });
  }
}
