// app/api/ed/_shared.ts
import axios from 'axios';
import https from 'node:https';
import fs from 'node:fs';

export const ED_BASE = 'https://api.ecoledirecte.com';
// Version récente (l’endpoint gtk=1 a été introduit en 2025)
export const ED_VERSION = '4.75.0';

export const UA =
  'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36';

const insecure = process.env.ED_INSECURE_TLS === '1'; // (optionnel pour debug derrière proxy TLS)
const caPath = process.env.ED_CA_CERT_PATH;

export const httpsAgent = caPath
  ? new https.Agent({ ca: fs.readFileSync(caPath) })
  : new https.Agent({ rejectUnauthorized: !insecure });

export const axiosBase = axios.create({
  httpsAgent,
  proxy: false,
  validateStatus: () => true,
  headers: { 'User-Agent': UA },
});

export const toForm = (d: any) => new URLSearchParams({ data: JSON.stringify(d) }).toString();

export function extractCookieJar(setCookie: string[] | undefined) {
  const jar: Record<string, string> = {};
  if (!setCookie) return jar;
  for (const line of setCookie) {
    const first = line.split(';')[0] ?? '';
    const eq = first.indexOf('=');
    if (eq > 0) {
      const name = first.slice(0, eq).trim();
      const value = first.slice(eq + 1).trim();
      if (name) jar[name] = value;
    }
  }
  return jar;
}

export function cookieHeaderFromJar(jar: Record<string, string>) {
  return Object.entries(jar)
    .map(([k, v]) => `${k}=${v}`)
    .join('; ');
}

/**
 * Prélogin officiel : force le serveur à poser le cookie GTK
 * via GET /v3/login.awp?gtk=1&v=ED_VERSION
 */
export async function prelogin() {
  const url = `${ED_BASE}/v3/login.awp?gtk=1&v=${ED_VERSION}`;
  try {
    const r = await axiosBase.get(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
        'X-Requested-With': 'XMLHttpRequest',
        Origin: 'https://www.ecoledirecte.com',
        Referer: 'https://www.ecoledirecte.com/',
      },
    });

    const jar = extractCookieJar(r.headers['set-cookie'] as string[] | undefined);
    const gtk = jar['GTK'] || null;

    if (gtk) {
      return { gtk, cookieHeader: cookieHeaderFromJar(jar), jar };
    }

    // Fallback rare : tenter la home publique (au cas où le tenant poserait GTK là)
    const rHtml = await axiosBase.get('https://www.ecoledirecte.com/', {
      headers: { Accept: 'text/html,*/*' },
    });
    const jar2 = extractCookieJar(rHtml.headers['set-cookie'] as string[] | undefined);
    const gtk2 = jar2['GTK'] || null;
    if (gtk2) {
      return { gtk: gtk2, cookieHeader: cookieHeaderFromJar(jar2), jar: jar2 };
    }

    return { gtk: null as string | null, cookieHeader: '', jar: {} };
  } catch {
    return { gtk: null as string | null, cookieHeader: '', jar: {} };
  }
}

export function baseHeaders(gtk: string, extra?: Record<string, string>) {
  return {
    'User-Agent': UA,
    Accept: 'application/json, text/plain, */*',
    'X-Requested-With': 'XMLHttpRequest',
    'X-Gtk': gtk,
    Origin: 'https://www.ecoledirecte.com',
    Referer: 'https://www.ecoledirecte.com/',
    Cookie: `GTK=${gtk}`,
    ...(extra || {}),
  };
}

export function mask(s: string | undefined | null, left = 2, right = 2) {
  if (!s) return '';
  if (s.length <= left + right) return '*'.repeat(s.length);
  return s.slice(0, left) + '…'.repeat(3) + s.slice(-right);
}

export function headerKeys(h: any) {
  return Object.keys(h || {}).sort();
}
