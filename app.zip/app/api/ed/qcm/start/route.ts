import { NextRequest, NextResponse } from 'next/server';
import { axiosBase, ED_BASE, ED_VERSION } from '../../_shared';

export const runtime = 'nodejs';
const DEBUG = true;

function ensureGtk(cookieHeader: string | undefined, gtk: string) {
  const ch = (cookieHeader || '').trim();
  if (!ch) return `GTK=${gtk}`;
  if (/(^|;\s*)GTK=[^;]+/.test(ch)) return ch;
  return `${ch}; GTK=${gtk}`;
}

function baseQcmHeaders(gtk: string, token: string, cookieHeader: string) {
  return {
    'User-Agent':
      'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36',
    Accept: 'application/json, text/plain, */*',
    'Accept-Language': 'fr-FR,fr;q=0.5',
    Pragma: 'no-cache',
    'Cache-Control': 'no-cache',
    'X-Requested-With': 'XMLHttpRequest',
    'X-Client': 'EDWEB',
    'X-Gtk': gtk,
    'X-Token': token,
    Origin: 'https://www.ecoledirecte.com',
    Referer: 'https://www.ecoledirecte.com/',
    Cookie: cookieHeader,
  } as const;
}

export async function POST(req: NextRequest) {
  try {
    const { gtk, token, cookieHeader } = await req.json();
    if (!gtk || !token) {
      return NextResponse.json({ error: 'gtk, token requis' }, { status: 400 });
    }
    const rawCH = (cookieHeader || '').trim();
    const decodedCH = /%[0-9A-Fa-f]{2}/.test(rawCH) ? decodeURIComponent(rawCH) : rawCH;
    const cookie = ensureGtk(decodedCH, gtk);

    const headers = baseQcmHeaders(gtk, token, cookie);
    if (DEBUG) {
      console.log('[ED/QCM start][COOKIE]', {
        len: headers.Cookie.length,
        hasPct: /%[0-9A-Fa-f]{2}/.test(headers.Cookie),
        hasGtk: /(^|;\s*)GTK=[^;]+/.test(headers.Cookie),
        sample: headers.Cookie.slice(0, 120) + (headers.Cookie.length > 120 ? '…' : ''),
      });
    }

    const urlGet = `${ED_BASE}/v3/connexion/doubleauth.awp?verbe=get&v=${ED_VERSION}`;
    const urlPost = `${ED_BASE}/v3/connexion/doubleauth.awp?verbe=post&v=${ED_VERSION}`;

    console.log('[ED/QCM start][REQUEST verbe=get]', {
      cookieLen: headers.Cookie.length,
      hasGtk: /GTK=/.test(headers.Cookie),
    });
    let r = await axiosBase.get(urlGet, { headers });
    let j = r.data;
    console.log('[ED/QCM start][RESPONSE verbe=get]', {
      httpStatus: r.status,
      code: j?.code,
      msg: j?.message ?? j?.msg ?? null,
    });
    if (j?.code === 200) return NextResponse.json({ ok: true, data: j?.data ?? null });

    // post init (text/plain)
    const bodyTxt = `data=${encodeURIComponent(JSON.stringify({}))}`;
    console.log('[ED/QCM start][REQUEST verbe=post-init][text/plain]');
    r = await axiosBase.post(urlPost, bodyTxt, {
      headers: { ...headers, 'Content-Type': 'text/plain;charset=UTF-8' },
    });
    j = r.data;
    console.log('[ED/QCM start][RESPONSE verbe=post-init][text/plain]', {
      httpStatus: r.status,
      code: j?.code,
      msg: j?.message ?? j?.msg ?? null,
    });

    if (j?.code !== 200) {
      // fallback form
      const formBody = new URLSearchParams({ data: JSON.stringify({}) }).toString();
      console.log('[ED/QCM start][REQUEST verbe=post-init][form]');
      r = await axiosBase.post(urlPost, formBody, {
        headers: { ...headers, 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      j = r.data;
      console.log('[ED/QCM start][RESPONSE verbe=post-init][form]', {
        httpStatus: r.status,
        code: j?.code,
        msg: j?.message ?? j?.msg ?? null,
      });
    }

    if (j?.code === 200) {
      console.log('[ED/QCM start][REQUEST verbe=get-2]');
      const r2 = await axiosBase.get(urlGet, { headers });
      const j2 = r2.data;
      console.log('[ED/QCM start][RESPONSE verbe=get-2]', {
        httpStatus: r2.status,
        code: j2?.code,
        msg: j2?.message ?? j2?.msg ?? null,
      });
      if (j2?.code === 200) return NextResponse.json({ ok: true, data: j2?.data ?? null });
    }

    return NextResponse.json({ error: j?.message || 'QCM start failed', raw: j }, { status: 502 });
  } catch (e: any) {
    console.error('[ED/QCM start] ERROR', e?.message || e);
    return NextResponse.json({ error: e?.message || 'Erreur serveur' }, { status: 500 });
  }
}
