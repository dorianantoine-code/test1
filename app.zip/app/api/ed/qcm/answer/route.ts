import { NextRequest, NextResponse } from 'next/server';
import { axiosBase, ED_BASE, ED_VERSION, toForm } from '../../_shared';

export const runtime = 'nodejs';
const DEBUG = true;

function ensureGtk(cookieHeader: string | undefined, gtk: string) {
  const ch = (cookieHeader || '').trim();
  if (!ch) return `GTK=${gtk}`;
  if (/(^|;\s*)GTK=[^;]+/.test(ch)) return ch;
  return `${ch}; GTK=${gtk}`;
}

function baseQcmHeaders(gtk: string, token: string, cookieHeader: string) {
  return {
    'User-Agent':
      'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36',
    Accept: 'application/json, text/plain, */*',
    'Accept-Language': 'fr-FR,fr;q=0.5',
    Pragma: 'no-cache',
    'Cache-Control': 'no-cache',
    'X-Requested-With': 'XMLHttpRequest',
    'X-Client': 'EDWEB',
    'X-Gtk': gtk,
    'X-Token': token,
    Origin: 'https://www.ecoledirecte.com',
    Referer: 'https://www.ecoledirecte.com/',
    Cookie: cookieHeader,
  } as const;
}

export async function POST(req: NextRequest) {
  try {
    const { gtk, token, cookieHeader, answer } = await req.json();
    if (!gtk || !token || !answer) {
      return NextResponse.json({ error: 'gtk, token, answer requis' }, { status: 400 });
    }
    const cookie = ensureGtk(cookieHeader, gtk);
    const headers = baseQcmHeaders(gtk, token, cookie);

    const urlPost = `${ED_BASE}/v3/connexion/doubleauth.awp?verbe=post&v=${ED_VERSION}`;

    // Essai text/plain (comme /login)
    const bodyTxt = `data=${encodeURIComponent(JSON.stringify({ reponse: answer }))}`;
    if (DEBUG) console.log('[ED/QCM answer][REQUEST text/plain]');
    let r = await axiosBase.post(urlPost, bodyTxt, {
      headers: { ...headers, 'Content-Type': 'text/plain;charset=UTF-8' },
    });
    let j = r.data;
    if (DEBUG)
      console.log('[ED/QCM answer][RESPONSE text/plain]', {
        httpStatus: r.status,
        code: j?.code,
        msg: j?.message ?? null,
      });

    if (j?.code !== 200) {
      // Fallback form
      const formBody = toForm({ reponse: answer });
      if (DEBUG) console.log('[ED/QCM answer][REQUEST form]');
      r = await axiosBase.post(urlPost, formBody, {
        headers: { ...headers, 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      j = r.data;
      if (DEBUG)
        console.log('[ED/QCM answer][RESPONSE form]', {
          httpStatus: r.status,
          code: j?.code,
          msg: j?.message ?? null,
        });
    }

    if (j?.code !== 200) {
      return NextResponse.json(
        { error: j?.message || 'QCM answer failed', raw: j },
        { status: 401 },
      );
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    if (DEBUG) console.error('[ED/QCM answer] ERROR', e?.message || e);
    return NextResponse.json({ error: e?.message || 'Erreur serveur' }, { status: 500 });
  }
}
