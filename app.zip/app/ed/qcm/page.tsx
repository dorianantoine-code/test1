'use client';
import { useEffect, useState } from 'react';

export default function QcmPage({ searchParams }: any) {
  const gtk = typeof searchParams?.gtk === 'string' ? searchParams.gtk : '';
  const token = typeof searchParams?.token === 'string' ? searchParams.token : '';
  const cookieHeader = typeof searchParams?.ch === 'string' ? searchParams.ch : '';

  const [question, setQuestion] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const start = async () => {
      setErr(null);
      setLoading(true);
      try {
        const r = await fetch('/api/ed/qcm/start', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ gtk, token, cookieHeader }),
        });
        const j = await r.json();
        if (!r.ok) {
          setErr(j.error || 'Erreur QCM start');
          return;
        }
        setQuestion(j.data || j);
      } catch (e: any) {
        setErr(e?.message || 'Erreur réseau');
      } finally {
        setLoading(false);
      }
    };
    if (gtk && token) start();
  }, [gtk, token, cookieHeader]);

  const submit = async (rep: string) => {
    setErr(null);
    setLoading(true);
    try {
      const r = await fetch('/api/ed/qcm/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gtk, token, cookieHeader, answer: rep }),
      });
      const j = await r.json();
      if (!r.ok) {
        setErr(j.error || 'Réponse refusée');
        return;
      }
      alert('Réponse validée ✅'); // ou redirection
    } catch (e: any) {
      setErr(e?.message || 'Erreur réseau');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen p-6">
      <h1 className="text-xl font-bold mb-4">Vérification supplémentaire</h1>
      {loading && <p>Chargement…</p>}
      {err && <p className="text-red-600">{err}</p>}
      {question?.libelle && (
        <div className="space-y-3">
          <p className="font-medium">{question.libelle}</p>
          <div className="space-y-2">
            {(question.choix || []).map((c: any, idx: number) => (
              <button
                key={idx}
                onClick={() => submit(c)}
                className="px-3 py-2 bg-blue-600 text-white rounded"
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
